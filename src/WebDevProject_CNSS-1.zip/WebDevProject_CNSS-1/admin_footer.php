<footer class="admin-footer">
    <p>CNSS Tech Admin Panel © 2026</p>
</footer>

</div> 
</body>
</html>

