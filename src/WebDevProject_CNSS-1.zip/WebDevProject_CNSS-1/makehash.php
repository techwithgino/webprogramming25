<?php
echo password_hash("test123", PASSWORD_DEFAULT);
